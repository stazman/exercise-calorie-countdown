class Countdown < ApplicationRecord
end